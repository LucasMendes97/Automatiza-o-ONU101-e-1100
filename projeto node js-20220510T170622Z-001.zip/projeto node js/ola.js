/**
 * Tutorial Rocketseat
 * https://www.youtube.com/watch?v=DiXbJL3iWVs&ab_channel=Rocketseat
 * Para no minuto: 43:23
 */

const os = require('os');
const log = require('./logger')

setInterval(() => {
  //desestruturação de objeto
  const { freemem, totalmem } = os;

  //constante memória livre
  const mem = parseInt(freemem() / 1024 / 1024);
  //constante total memória
  const total = parseInt(totalmem() / 1024 / 1024);
  //percentual
  const percents = parseInt((mem / total) * 100);

  const stats = {
    free: `${mem} MB`,
    total: `${total} MB`,
    usage: `${percents}%`
  }
  console.clear();
  console.log("====PC JESSIQUINHA====");
  console.table(stats);

  log(`${JSON.stringify(stats)}\n`);

}, 500) 